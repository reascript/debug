--[[
     * ReaScript Name: TrackFX Routing Matrix
     * Lua script for Cockos REAPER
     * Author: Amagalma
     * Author URI: https://forum.cockos.com/member.php?u=32436
     * Version: 1.0
    ]]


-- Check if JS_ReaScriptAPI is installed
if not reaper.APIExists("JS_Window_Find") then
  reaper.MB( "Please, install the JS_ReaScriptAPI for this action to run.", "JS_ReaScriptAPI missing..", 0 )
  return reaper.defer(function() end)
end
----------------------------------------------------------------------
local Zerobrane_path = reaper.GetExtState( "Debugger", "Zerobrane path" )
if not reaper.file_exists(Zerobrane_path) or not Zerobrane_path:match("zbstudio.%exe") then
  ok, fileName = reaper.JS_Dialog_BrowseForOpenFiles( "Browse for zbstudio.exe", "C:/", "zbstudio.exe",
                 "Executable files (.exe)\0*.exe\0\0", false )
  if ok and fileName:match("zbstudio.%exe") then
    reaper.SetExtState( "Debugger", "Zerobrane path", fileName, true )
    reaper.MB("Zerobrane Studio path is set. Please, re-run script.", "Success!", 0)
  end
  return reaper.defer(function() end)
end
----------------------------------------------------------------------
local ReascriptIDE = reaper.JS_Window_Find( " - ReaScript Development Environment", false )
if not ReascriptIDE then return reaper.defer(function() end) end

local ScriptName = reaper.JS_Window_GetTitle( ReascriptIDE ):gsub(" %- ReaScript Development Environment", "")

if reaper.GetToggleCommandState( 40605 ) ~= 1 then
  reaper.Main_OnCommand(40605, 0) -- Show action list
  opened_actionlist = true
end

local ActionListHWND = reaper.JS_Window_Find("Actions", true)
local FilterHWND = reaper.JS_Window_FindChildByID(ActionListHWND, 1324)
local search_filter = reaper.JS_Window_GetTitle( FilterHWND )
local ListViewHWND = reaper.JS_Window_FindChildByID(ActionListHWND, 1323)
-- Make sure ReaScript path column is visible
local ListViewHeaderHWND = reaper.JS_Window_HandleFromAddress(reaper.JS_WindowMessage_Send(ListViewHWND, "0x101F", 0,0,0,0)) -- 0x101F = LVM_GETHEADER
local ListViewColumnCount = reaper.JS_WindowMessage_Send(ListViewHeaderHWND, "0x1200" ,0,0,0,0) -- 0x1200 = HDM_GETITEMCOUNT
local listview_item_to_get = 4 -- fifth
if ListViewColumnCount == 3 then
  restore_columns = {41170, 41387}
  reaper.JS_WindowMessage_Send(ActionListHWND, "WM_COMMAND", 41170, 0, 0, 0) -- IDs
  reaper.JS_WindowMessage_Send(ActionListHWND, "WM_COMMAND", 41387, 0, 0, 0) -- Paths
elseif ListViewColumnCount == 4 then
  local fourth_item = reaper.JS_ListView_GetItem( ListViewHWND, 0, 3 )
  if fourth_item:match("%d+") or fourth_item:match("^_") then
    -- Is Command ID
    restore_columns = {41387}
    reaper.JS_WindowMessage_Send(ActionListHWND, "WM_COMMAND", 41387, 0, 0, 0) -- Paths
  else
    -- Is Path
    listview_item_to_get = 3 -- fourth
  end
end
reaper.JS_Window_SetTitle( FilterHWND, ScriptName )

local sep = package.config:sub(1,1)
local wanted_column_name = "Script: " .. ScriptName

local end_time = reaper.time_precise() + 4
local function loop()
  local time = reaper.time_precise()
  if reaper.JS_ListView_GetItem( ListViewHWND, 0, 1 ) == wanted_column_name then
    local ScriptPath = reaper.JS_ListView_GetItem( ListViewHWND, 0, listview_item_to_get )
    reaper.JS_Window_SetTitle( FilterHWND, search_filter )
    if restore_columns then
      for i = 1, #restore_columns do
        reaper.JS_WindowMessage_Send(ActionListHWND, "WM_COMMAND", restore_columns[i], 0, 0, 0)
      end
    end
    if opened_actionlist then
      reaper.JS_Window_Destroy( ActionListHWND )
    end
    -- check if path is absolute
    local absolute
    if (reaper.GetOS()):match("Win") then
      if ScriptPath:match("^%a:\\") or ScriptPath:match("^\\\\") then
        absolute = true
      end
    else -- unix
      absolute = ScriptPath:match("^/")
    end
    ScriptPath = ScriptPath .. sep .. ScriptName
    if not absolute then
      ScriptPath = reaper.GetResourcePath() .. sep .. "Scripts" .. sep .. ScriptPath
    end
    if reaper.file_exists( ScriptPath ) then
      reaper.CF_SetClipboard( 'require("mobdebug").start()' )
      reaper.ClearConsole()
      reaper.ShowConsoleMsg('- Paste this line to the top of your script: (copied to Clipboard)\n\n\t\z
      require("mobdebug").start()\n\n- In Zerobrane, enable:\n\n\tProject -> Start Debugger Server\n\n')
      if Zerobrane_path:match('^".+"$') then
        Zerobrane_path = Zerobrane_path:sub(2, #Zerobrane_path-1)
      end
      reaper.ExecProcess( '"' .. Zerobrane_path .. '" "' .. ScriptPath .. '"', -1 )
    end
    return reaper.defer(function() end)
  elseif time > end_time then
    return reaper.defer(function() end)
  else
    reaper.defer(loop)
  end
end

loop()